#!/bin/bash
#author:elain
#ctime:20130614
#The scripts for install gogent on ubuntu


echo "============开始安装依赖…………==========="
sudo apt-get install python-dev python-openssl python-appindicator python-vte -y
tar xvzf greenlet-0.4.0.tar.gz && cd greenlet-0.4.0 && sudo python setup.py install
echo "=============安装依赖完成==============="
sleep 2
echo "===========开始安装goagent…………=========="
unzip goagent-goagent-v3.0.1-45-gdff8f38.zip 
sudo mkdir -p ~/apps
mv goagent-goagent-dff8f38 ~/apps/goagent
cd  ~/apps/goagent
cd server
sleep 1
python uploader.zip

echo '''
===============================================
更多详细配置请参考：
https://code.google.com/p/goagent/wiki/InstallGuide
===============================================
'''
